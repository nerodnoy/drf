from django.contrib import admin
from .models import Restaurants

admin.site.register(Restaurants)
